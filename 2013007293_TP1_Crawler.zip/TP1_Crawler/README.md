
Para executar o Crawler execute o arquivo "execute.sh".

Qualquer duvida na entrada de par�metros, h� coment�rios no mesmo arquivo.

Comando: ./execute.sh