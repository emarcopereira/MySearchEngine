#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <random>
#include "../source/monitor.hpp"
#include <chrono>

using namespace std;

int main(){
	char urls[8][100] = { 
		"http://www.decolar.com",
		"http://www.tripadvisor.com.br",
		"http://www.latam.com",
		"http://www.voeazul.com.br",
		"http://www.cvc.com.br",
		"http://www.globo.com",
		"http://ufmg.br",
		"http://dcc.ufmg.br"
	};

	CkSpider ck_spider;
	Url url_manger(&ck_spider);

	chrono::steady_clock::time_point start_time = chrono::steady_clock::now();
	Logger logger(0, "test", "test.logger", 500000, start_time);
	Dumper dumper("test", "test.dump", 5000000);
	Spider spider(1000, 1000, &logger, &dumper);

	random_device rd;  //Will be used to obtain a seed for the random number engine
    mt19937 generator(rd());
	uniform_int_distribution<int> distribution(1,8);
	int rand = distribution(generator);

	string canonized_url = url_manger.getCleanUrl(urls[rand-1]);
	string domain = url_manger.getDomain(canonized_url);
	int n_levels = url_manger.getNumberLevels(canonized_url);
	printf("\ngetCleanUrl: %s", canonized_url.c_str());
	printf("\nisBrDomain: %s", url_manger.isBrDomain(urls[rand-1])? "true" : "false");
	printf("\ngetDomain: %s", domain.c_str());
	printf("\ngetNumberLevels: %d", n_levels);

	UrlCarrier url_carrier(canonized_url, domain, n_levels, 999);

	spider.collect(url_carrier);

	return 0;
}